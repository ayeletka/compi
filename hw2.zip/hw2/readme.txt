
Ayelet Kalderon 200980357
Avishag Daniely 305664609



I (We) assert that the work we submitted is 100% our own. We have not received any
part from any other student in the class, nor have we give parts of it for use to others.
Nor have we used code from other sources: Courses taught previously at this university,
courses taught at other universities, various bits of code found on the internet, etc.
We realize that should our code be found to contain code from other sources, that a
formal case shall be opened against us with משמעת ועדת, in pursuit of disciplinary
action